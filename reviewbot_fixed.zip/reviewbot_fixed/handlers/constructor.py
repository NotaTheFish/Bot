"""
Хендлер конструктора карточек — пошаговое создание с живым превью.
"""
import secrets
import string
from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    BufferedInputFile, InputMediaPhoto
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from db import Database
from services.constructor import (
    LAYOUTS, FONTS, TEXT_COLORS, ACCENT_COLORS, BG_COLORS,
    BG_GRADIENTS, CARD_BORDERS, CARD_RADIUS, CARD_SHADOW, TEXT_SIZES,
    CORNER_FILL, VISIBILITY_DEFAULTS,
    TITLE_EFFECTS, BG_TEXTURES, PRESETS,
    VERIFIED_BADGES, CORNER_ORNAMENTS,
    render_preview
)

import logging
router = Router()
logger = logging.getLogger(__name__)

MAX_TEMPLATES = 15


class ConstructorSG(StatesGroup):
    building = State()      # активное конструирование с превью
    enter_bg_image = State()
    enter_logo = State()
    enter_name = State()
    enter_key = State()     # ввод ключа для получения шаблона
    enter_anon_nick = State()
    enter_anon_avatar = State()


def _default_cfg() -> dict:
    return {
        "layout": "classic",
        "font": "montserrat",
        "title_font": "caveat",
        "text_color": "#f0f0f0",
        "accent_color": "#c9a84c",
        "bg_color": "#1a1a2e",
        "bg_image": None,
        "creator_username": None,
        "is_edited": False,
        "extra_cfg": {},
    }


# ── Клавиатуры конструктора ────────────────────────────────────────────────

def kb_constructor_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✨ Готовые стили (пресеты)", callback_data="con:menu:presets")],
        [InlineKeyboardButton(text="📐 Раскладка", callback_data="con:menu:layout")],
        [InlineKeyboardButton(text="🔤 Шрифт названия", callback_data="con:menu:title_font"),
         InlineKeyboardButton(text="🔡 Шрифт текста", callback_data="con:menu:font")],
        [InlineKeyboardButton(text="🎨 Цвет текста", callback_data="con:menu:text_color"),
         InlineKeyboardButton(text="✨ Акцент", callback_data="con:menu:accent_color")],
        [InlineKeyboardButton(text="🌌 Фон (цвет)", callback_data="con:menu:bg_color"),
         InlineKeyboardButton(text="🌈 Градиент", callback_data="con:menu:bg_gradient")],
        [InlineKeyboardButton(text="🖼 Фон (картинка)", callback_data="con:menu:bg_image")],
        [InlineKeyboardButton(text="🔲 Рамка", callback_data="con:menu:card_border"),
         InlineKeyboardButton(text="⬜️ Углы", callback_data="con:menu:card_radius")],
        [InlineKeyboardButton(text="🎨 Заливка углов", callback_data="con:menu:corner_fill"),
         InlineKeyboardButton(text="🌫 Тень", callback_data="con:menu:card_shadow")],
        [InlineKeyboardButton(text="💫 Эффект названия", callback_data="con:menu:title_effect"),
         InlineKeyboardButton(text="🧩 Текстура фона", callback_data="con:menu:bg_texture")],
        [InlineKeyboardButton(text="🔠 Размер текста", callback_data="con:menu:text_size")],
        [InlineKeyboardButton(text="👁 Показать/скрыть блоки", callback_data="con:menu:visibility")],
        [InlineKeyboardButton(text="✅ Бейдж продавца", callback_data="con:menu:verified_badge"),
         InlineKeyboardButton(text="⌜ Орнамент углов", callback_data="con:menu:corner_ornament")],
        [InlineKeyboardButton(text="🖼 Логотип магазина", callback_data="con:menu:logo")],
        [InlineKeyboardButton(text="🕵️ Анон-профиль карточки", callback_data="con:menu:anon")],
        [InlineKeyboardButton(text="💾 Сохранить шаблон", callback_data="con:save")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="con:cancel")],
    ])


def _kb_options(prefix: str, options: dict, back="con:back", cols: int = 1) -> InlineKeyboardMarkup:
    rows = []
    items = list(options.items())
    row = []
    for key, val in items:
        label = val[0] if isinstance(val, tuple) else val
        row.append(InlineKeyboardButton(text=label, callback_data=f"con:set:{prefix}:{key}"))
        if len(row) >= cols:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="« Назад", callback_data=back)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


VIS_LABELS = {
    "show_date": "📅 Дата",
    "show_item": "📦 Товар",
    "show_avatar": "👤 Аватар",
    "show_seller_tag": "🏷 Тег продавца",
    "show_quote": "❝ Кавычки",
}


def _kb_presets() -> InlineKeyboardMarkup:
    rows = []
    for key, preset in PRESETS.items():
        rows.append([InlineKeyboardButton(text=preset["label"], callback_data=f"con:preset:{key}")])
    rows.append([InlineKeyboardButton(text="« Назад", callback_data="con:back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _kb_visibility(cfg: dict) -> InlineKeyboardMarkup:
    ex = cfg.get("extra_cfg") or {}
    rows = []
    for key, label in VIS_LABELS.items():
        cur = ex.get(key, VISIBILITY_DEFAULTS[key])
        mark = "✅" if cur else "❌"
        rows.append([InlineKeyboardButton(
            text=f"{mark} {label}", callback_data=f"con:toggle:{key}"
        )])
    rows.append([InlineKeyboardButton(text="« Назад", callback_data="con:back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ── Запуск конструктора ────────────────────────────────────────────────────

async def start_constructor(message: Message, state: FSMContext, db: Database, bot_username: str = "reviewbot"):
    count = await db.count_custom_templates(message.from_user.id)
    if count >= MAX_TEMPLATES:
        await message.answer(
            f"❌ У тебя уже {MAX_TEMPLATES} шаблонов — это максимум. "
            f"Удали один из старых чтобы создать новый."
        )
        return

    cfg = _default_cfg()
    await state.set_state(ConstructorSG.building)
    await state.update_data(cfg=cfg, preview_msg_id=None, bot_username=bot_username)
    await _send_or_update_preview(message, state, db, first=True)


async def start_constructor_edit(message: Message, state: FSMContext, db: Database,
                                  tpl: dict, bot_username: str = "reviewbot"):
    """Запускает конструктор с загруженным существующим шаблоном для редактирования."""
    cfg = {
        "layout": tpl["layout"],
        "font": tpl["font"],
        "title_font": tpl.get("title_font", "caveat"),
        "text_color": tpl["text_color"],
        "accent_color": tpl["accent_color"],
        "bg_color": tpl["bg_color"],
        "bg_image": tpl["bg_image"],
        "creator_username": tpl["creator_username"],
        "is_edited": tpl["is_edited"],
        "extra_cfg": tpl.get("extra_cfg") or {},
        "anon_nickname": tpl.get("anon_nickname"),
        "anon_avatar": tpl.get("anon_avatar"),
    }
    await state.set_state(ConstructorSG.building)
    await state.update_data(
        cfg=cfg, preview_msg_id=None, bot_username=bot_username,
        edit_template_id=tpl["id"],          # id редактируемого шаблона
        edit_template_name=tpl["name"],
        is_received=(tpl["owner_id"] != tpl["creator_id"]),  # чужой ли шаблон
    )
    await _send_or_update_preview(message, state, db, first=True)


async def _send_or_update_preview(message_or_call, state: FSMContext, db: Database, first=False):
    data = await state.get_data()
    cfg = data["cfg"]

    if isinstance(message_or_call, CallbackQuery):
        chat = message_or_call.message.chat
        bot = message_or_call.bot
    else:
        chat = message_or_call.chat
        bot = message_or_call.bot

    bot_username = data.get("bot_username", "reviewbot")
    png = await render_preview(cfg, bot_username)
    media = InputMediaPhoto(
        media=BufferedInputFile(png, filename="preview.png"),
        caption="🎨 <b>Конструктор карточки</b>\n\nНастраивай элементы — превью обновляется вживую."
    )

    preview_id = data.get("preview_msg_id")
    if preview_id:
        try:
            await bot.edit_message_media(
                chat_id=chat.id, message_id=preview_id,
                media=media, reply_markup=kb_constructor_main()
            )
            return
        except Exception:
            pass

    sent = await bot.send_photo(
        chat_id=chat.id,
        photo=BufferedInputFile(png, filename="preview.png"),
        caption="🎨 <b>Конструктор карточки</b>\n\nНастраивай элементы — превью обновляется вживую.",
        reply_markup=kb_constructor_main()
    )
    await state.update_data(preview_msg_id=sent.message_id)


async def _refresh_preview_in_place(call: CallbackQuery, state: FSMContext, db: Database,
                                    keyboard=None, expect_menu=None):
    """Перерисовывает превью в существующем сообщении.
    keyboard=None — возвращает главное меню конструктора;
    иначе оставляет переданную клавиатуру (например меню выбора цвета).
    expect_menu — имя меню, которое должно быть активным; если за время рендера
    пользователь нажал «Назад» (active_menu изменился), клавиатура не перезаписывается."""
    data = await state.get_data()
    cfg = data["cfg"]
    bot_username = data.get("bot_username", "reviewbot")
    preview_id = data.get("preview_msg_id")
    chat_id = call.message.chat.id

    # Рендерим (медленно) ДО финального выбора клавиатуры
    png = await render_preview(cfg, bot_username)

    # После рендера перечитываем состояние — мог измениться active_menu
    if expect_menu is not None:
        fresh = await state.get_data()
        if fresh.get("active_menu") != expect_menu:
            # Пользователь ушёл из этого меню (нажал «Назад») — не навязываем меню параметра
            kb = kb_constructor_main()
        else:
            kb = keyboard if keyboard is not None else kb_constructor_main()
    else:
        kb = keyboard if keyboard is not None else kb_constructor_main()

    media = InputMediaPhoto(
        media=BufferedInputFile(png, filename="preview.png"),
        caption="🎨 <b>Конструктор карточки</b>\n\nНастраивай элементы — превью обновляется вживую."
    )
    if preview_id:
        try:
            await call.bot.edit_message_media(
                chat_id=chat_id, message_id=preview_id,
                media=media, reply_markup=kb
            )
            return
        except Exception:
            pass
    # Фолбэк — отправляем заново
    sent = await call.bot.send_photo(
        chat_id=chat_id,
        photo=BufferedInputFile(png, filename="preview.png"),
        caption="🎨 <b>Конструктор карточки</b>\n\nНастраивай элементы — превью обновляется вживую.",
        reply_markup=kb
    )
    await state.update_data(preview_msg_id=sent.message_id)


# ── Навигация по меню настроек ─────────────────────────────────────────────

MENU_MAP = {
    "layout": ("📐 Выбери раскладку:", LAYOUTS),
    "font": ("🔡 Шрифт основного текста:", FONTS),
    "title_font": ("🔤 Шрифт названия магазина:", FONTS),
    "text_color": ("🎨 Цвет текста:", TEXT_COLORS),
    "accent_color": ("✨ Цвет акцента (рамки, звёзды):", ACCENT_COLORS),
    "bg_color": ("🌌 Цвет фона:", BG_COLORS),
    "bg_gradient": ("🌈 Градиентный фон:", BG_GRADIENTS),
    "card_border": ("🔲 Рамка карточки:", CARD_BORDERS),
    "card_radius": ("⬜️ Скругление углов:", CARD_RADIUS),
    "card_shadow": ("🌫 Тень карточки:", CARD_SHADOW),
    "text_size": ("🔠 Размер текста отзыва:", TEXT_SIZES),
    "corner_fill": ("🎨 Заливка углов (когда скруглены):", CORNER_FILL),
    "title_effect": ("💫 Эффект названия магазина:", TITLE_EFFECTS),
    "bg_texture": ("🧩 Текстура фона:", BG_TEXTURES),
    "verified_badge": ("✅ Бейдж проверенного продавца:", VERIFIED_BADGES),
    "corner_ornament": ("⌜ Орнамент углов карточки:", CORNER_ORNAMENTS),
}


@router.callback_query(ConstructorSG.building, F.data.startswith("con:anon:"))
async def cb_con_anon(call: CallbackQuery, state: FSMContext, db: Database):
    action = call.data.split(":")[2]
    await call.answer()

    if action == "nick":
        await state.set_state(ConstructorSG.enter_anon_nick)
        await call.message.answer(
            "✏️ Пришли ник анонима <b>для этой карточки</b>.\n\n"
            "Например: <code>Хацкер аноним</code>, <code>Безымянный в маске</code>, "
            "<code>Таинственный грибоман</code>.\n\n"
            "Отправь /skip чтобы вернуться без изменений."
        )
        return

    if action == "avatar":
        await state.set_state(ConstructorSG.enter_anon_avatar)
        prompt = await call.message.answer(
            "🖼 Пришли картинку — аватар анонима <b>для этой карточки</b>.\n\n"
            "Лучше квадратную. Отправь /skip чтобы вернуться без изменений."
        )
        await state.update_data(upload_prompt_id=prompt.message_id)
        return

    if action == "reset":
        data = await state.get_data()
        cfg = data["cfg"]
        cfg["anon_nickname"] = None
        cfg["anon_avatar"] = None
        await state.update_data(cfg=cfg)
        await call.message.answer(
            "🗑 Анон-профиль карточки сброшен — будут использоваться настройки продавца."
        )
        return


@router.message(ConstructorSG.enter_anon_nick, F.text == "/skip")
async def con_anon_nick_skip(message: Message, state: FSMContext):
    await state.set_state(ConstructorSG.building)
    await message.answer("Оставил как было.")


@router.message(ConstructorSG.enter_anon_nick, F.text)
async def con_anon_nick_input(message: Message, state: FSMContext, db: Database):
    nick = message.text.strip()[:40]
    if not nick:
        await message.answer("Пустой ник. Пришли текст или /skip.")
        return
    data = await state.get_data()
    cfg = data["cfg"]
    cfg["anon_nickname"] = nick
    await state.update_data(cfg=cfg)
    await state.set_state(ConstructorSG.building)
    import html as _hh
    await message.answer(f"✅ Ник анонима для карточки: <b>{_hh.escape(nick)}</b>\n\n"
                         "<i>Не забудь сохранить шаблон.</i>")


@router.message(ConstructorSG.enter_anon_avatar, F.text == "/skip")
async def con_anon_avatar_skip(message: Message, state: FSMContext):
    await state.set_state(ConstructorSG.building)
    await message.answer("Оставил как было.")


@router.message(ConstructorSG.enter_anon_avatar, F.photo)
async def con_anon_avatar_input(message: Message, state: FSMContext, db: Database, bot):
    import base64, io
    photo = message.photo[-1]
    if photo.file_size and photo.file_size > 10 * 1024 * 1024:
        await message.answer("⚠️ Картинка слишком большая (макс 10 МБ).")
        return
    try:
        file = await bot.get_file(photo.file_id)
        buf = await bot.download_file(file.file_path)
        raw = buf.read()
        from PIL import Image
        Image.MAX_IMAGE_PIXELS = 40_000_000
        im = Image.open(io.BytesIO(raw)); im.load()
        im = im.convert("RGB")
        w, h = im.size
        side = min(w, h)
        im = im.crop(((w - side) // 2, (h - side) // 2, (w + side) // 2, (h + side) // 2))
        im.thumbnail((256, 256), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, format="JPEG", quality=85, optimize=True)
        b64 = base64.b64encode(out.getvalue()).decode()
    except Exception:
        await message.answer("⚠️ Не удалось обработать картинку. Пришли другую.")
        return
    data = await state.get_data()
    cfg = data["cfg"]
    cfg["anon_avatar"] = b64
    await state.update_data(cfg=cfg)
    await state.set_state(ConstructorSG.building)
    await message.answer("✅ Аватар анонима для карточки сохранён.\n\n"
                         "<i>Не забудь сохранить шаблон.</i>")


@router.message(ConstructorSG.enter_anon_avatar)
async def con_anon_avatar_wrong(message: Message):
    await message.answer("Пришли именно картинку (фото) или /skip.")


@router.callback_query(ConstructorSG.building, F.data.startswith("con:menu:"))
async def cb_open_menu(call: CallbackQuery, state: FSMContext):
    field = call.data.split(":")[2]
    await call.answer()

    if field == "anon":
        data = await state.get_data()
        cfg = data["cfg"]
        nick = cfg.get("anon_nickname")
        has_av = bool(cfg.get("anon_avatar"))
        import html as _hh
        rows = [
            [InlineKeyboardButton(text="✏️ Ник анонима для этой карточки",
                                  callback_data="con:anon:nick")],
            [InlineKeyboardButton(text="🖼 Аватар анонима" + (" ✅" if has_av else ""),
                                  callback_data="con:anon:avatar")],
        ]
        if nick or has_av:
            rows.append([InlineKeyboardButton(text="🗑 Сбросить (брать из настроек продавца)",
                                              callback_data="con:anon:reset")])
        rows.append([InlineKeyboardButton(text="« Назад", callback_data="con:back")])
        await call.message.answer(
            "🕵️ <b>Анон-профиль этой карточки</b>\n\n"
            "Можно задать ник и аватар анонима <b>отдельно для этой карточки</b>. "
            "Например, для хакерского стиля — «Хацкер аноним», для хоррора — «Безымянный в маске».\n\n"
            f"• Ник: <b>{_hh.escape(nick) if nick else 'из настроек продавца'}</b>\n"
            f"• Аватар: <b>{'задан для карточки' if has_av else 'из настроек продавца'}</b>\n\n"
            "<i>Если не задавать — берётся то, что настроено в «Мой торговый шаблон» → "
            "«Анонимные отзывы». Ник и аватар наследуются независимо.</i>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
        return

    if field == "bg_image":
        await state.set_state(ConstructorSG.enter_bg_image)
        prompt = await call.message.answer(
            "🖼 Пришли картинку которая станет фоном карточки.\n"
            "<i>Текст автоматически затемнится для читаемости. "
            "Отправь /skip чтобы вернуться без картинки.</i>"
        )
        await state.update_data(upload_prompt_id=prompt.message_id)
        return

    if field == "logo":
        await state.set_state(ConstructorSG.enter_logo)
        prompt = await call.message.answer(
            "🖼 Пришли логотип магазина.\n\n"
            "💡 <b>Важно про прозрачность:</b> если в логотипе прозрачный фон, "
            "отправь его как <b>файл</b> (📎 → «Файл» / «Без сжатия»), а не как фото — "
            "иначе Telegram зальёт прозрачность белым.\n\n"
            "<i>Он появится над названием. Отправь /skip чтобы убрать логотип.</i>"
        )
        await state.update_data(upload_prompt_id=prompt.message_id)
        return

    if field == "presets":
        data = await state.get_data()
        preview_id = data.get("preview_msg_id")
        kb = _kb_presets()
        if preview_id:
            try:
                await call.bot.edit_message_reply_markup(
                    chat_id=call.message.chat.id, message_id=preview_id, reply_markup=kb)
                return
            except Exception:
                pass
        await call.message.answer("✨ <b>Готовые стили</b>", reply_markup=kb)
        return

    if field == "visibility":
        data = await state.get_data()
        cfg = data["cfg"]
        preview_id = data.get("preview_msg_id")
        kb = _kb_visibility(cfg)
        if preview_id:
            try:
                await call.bot.edit_message_reply_markup(
                    chat_id=call.message.chat.id, message_id=preview_id, reply_markup=kb)
                return
            except Exception:
                pass
        await call.message.answer("👁 <b>Показать / скрыть блоки</b>", reply_markup=kb)
        return

    title, options = MENU_MAP[field]
    data = await state.get_data()
    preview_id = data.get("preview_msg_id")
    # Запоминаем активное меню (для защиты от гонки с «Назад»)
    await state.update_data(active_menu=field)
    # Цветовые палитры — в 2 колонки, чтобы меню было компактным
    color_fields = {"text_color", "accent_color", "bg_color"}
    cols = 2 if field in color_fields else 1
    kb = _kb_options(field, options, cols=cols)
    # Редактируем клавиатуру самого превью-сообщения (не плодим новые сообщения)
    if preview_id:
        try:
            await call.bot.edit_message_reply_markup(
                chat_id=call.message.chat.id, message_id=preview_id, reply_markup=kb)
            return
        except Exception:
            pass
    await call.message.answer(title, reply_markup=kb)


@router.callback_query(ConstructorSG.building, F.data.startswith("con:set:"))
async def cb_set_option(call: CallbackQuery, state: FSMContext, db: Database):
    _, _, field, value = call.data.split(":", 3)
    data = await state.get_data()
    cfg = data["cfg"]

    # Вычисляем новое значение и сравниваем с текущим
    if field == "text_color":
        new_val = TEXT_COLORS[value][1]
        changed = cfg.get("text_color") != new_val
        cfg["text_color"] = new_val
    elif field == "accent_color":
        new_val = ACCENT_COLORS[value][1]
        changed = cfg.get("accent_color") != new_val
        cfg["accent_color"] = new_val
    elif field == "bg_color":
        new_val = BG_COLORS[value][1]
        ex = cfg.setdefault("extra_cfg", {})
        changed = (cfg.get("bg_color") != new_val or cfg.get("bg_image") is not None
                   or ex.get("bg_gradient", "none") != "none")
        cfg["bg_color"] = new_val
        cfg["bg_image"] = None       # цвет отменяет картинку
        ex["bg_gradient"] = "none"   # и градиент — иначе он перекрыл бы цвет
    elif field == "layout":
        changed = cfg.get("layout") != value
        cfg["layout"] = value
    elif field == "font":
        changed = cfg.get("font") != value
        cfg["font"] = value
    elif field == "title_font":
        changed = cfg.get("title_font") != value
        cfg["title_font"] = value
    elif field in ("bg_gradient", "card_border", "card_radius", "card_shadow", "text_size", "corner_fill",
                   "title_effect", "bg_texture", "verified_badge", "corner_ornament"):
        ex = cfg.setdefault("extra_cfg", {})
        changed = ex.get(field) != value
        ex[field] = value
        # Градиент отменяет картинку-фон
        if field == "bg_gradient" and value != "none":
            cfg["bg_image"] = None
    else:
        changed = False

    await state.update_data(cfg=cfg)
    # Помечаем что сейчас активно меню этого параметра (для защиты от гонки с «Назад»)
    await state.update_data(active_menu=field)
    if not changed:
        await call.answer("Уже выбрано ✓")
    else:
        await call.answer("✅ Применено")
    # Перерисовываем превью, НО оставляем то же меню выбора открытым —
    # чтобы можно было перебирать варианты подряд (цвета, шрифты и т.д.)
    if field in MENU_MAP:
        _, options = MENU_MAP[field]
        color_fields = {"text_color", "accent_color", "bg_color"}
        cols = 2 if field in color_fields else 1
        same_menu = _kb_options(field, options, cols=cols)
        # Передаём ожидаемое имя меню — если юзер успел нажать «Назад»,
        # рендер не перезапишет клавиатуру обратно
        await _refresh_preview_in_place(call, state, db, keyboard=same_menu,
                                        expect_menu=field)
    else:
        await _refresh_preview_in_place(call, state, db)


@router.callback_query(ConstructorSG.building, F.data.startswith("con:toggle:"))
async def cb_toggle_visibility(call: CallbackQuery, state: FSMContext, db: Database):
    key = call.data.split(":")[2]
    if key not in VISIBILITY_DEFAULTS:
        await call.answer()
        return
    data = await state.get_data()
    cfg = data["cfg"]
    ex = cfg.setdefault("extra_cfg", {})
    cur = ex.get(key, VISIBILITY_DEFAULTS[key])
    ex[key] = not cur
    await state.update_data(cfg=cfg)
    await call.answer("Переключено")
    # Перерисовываем превью + оставляем клавиатуру тумблеров
    bot_username = data.get("bot_username", "reviewbot")
    preview_id = data.get("preview_msg_id")
    png = await render_preview(cfg, bot_username)
    media = InputMediaPhoto(
        media=BufferedInputFile(png, filename="preview.png"),
        caption="👁 <b>Показать / скрыть блоки</b>\n\nНажми чтобы переключить. «Назад» — к меню."
    )
    try:
        await call.bot.edit_message_media(
            chat_id=call.message.chat.id, message_id=preview_id,
            media=media, reply_markup=_kb_visibility(cfg)
        )
    except Exception:
        try:
            await call.message.edit_reply_markup(reply_markup=_kb_visibility(cfg))
        except Exception:
            pass


@router.callback_query(ConstructorSG.building, F.data.startswith("con:preset:"))
async def cb_apply_preset(call: CallbackQuery, state: FSMContext, db: Database):
    key = call.data.split(":")[2]
    preset = PRESETS.get(key)
    if not preset:
        await call.answer("Стиль не найден", show_alert=True)
        return
    data = await state.get_data()
    cfg = data["cfg"]
    # Применяем базовые поля
    for k, v in preset["base"].items():
        cfg[k] = v
    # Картинка-фон отменяется пресетом
    cfg["bg_image"] = None
    # Применяем extra_cfg (сохраняя тумблеры видимости пользователя)
    ex = cfg.setdefault("extra_cfg", {})
    vis_keys = set(VISIBILITY_DEFAULTS.keys())
    saved_vis = {k: ex[k] for k in vis_keys if k in ex}
    ex.update(preset["extra"])
    ex.update(saved_vis)  # видимость блоков не трогаем
    await state.update_data(cfg=cfg)
    await call.answer(f"✅ Применён стиль: {preset['label']}")
    await _refresh_preview_in_place(call, state, db)


@router.callback_query(ConstructorSG.building, F.data == "con:back")
async def cb_back_to_preview(call: CallbackQuery, state: FSMContext, db: Database):
    await call.answer()
    # Помечаем что пользователь ушёл в главное меню — даже если рендер параметра
    # ещё идёт, он увидит active_menu="main" и не перезапишет клавиатуру
    await state.update_data(active_menu="main")
    data = await state.get_data()
    preview_id = data.get("preview_msg_id")
    # Возвращаем главное меню на превью-сообщение
    if preview_id:
        try:
            await call.bot.edit_message_reply_markup(
                chat_id=call.message.chat.id, message_id=preview_id,
                reply_markup=kb_constructor_main()
            )
            return
        except Exception:
            pass
    # Фолбэк — перерисовать
    await _refresh_preview_in_place(call, state, db)


@router.message(ConstructorSG.enter_bg_image, F.photo)
async def cb_bg_image(message: Message, state: FSMContext, db: Database, bot):
    import base64, io
    photo = message.photo[-1]
    if photo.file_size and photo.file_size > 10 * 1024 * 1024:
        await message.answer("⚠️ Картинка слишком большая (макс 10 МБ). Пришли поменьше.")
        return
    file = await bot.get_file(photo.file_id)
    buf = await bot.download_file(file.file_path)
    raw = buf.read()
    # Защита от decompression-бомб + пережатие фона до разумного размера
    try:
        from PIL import Image
        Image.MAX_IMAGE_PIXELS = 40_000_000
        im = Image.open(io.BytesIO(raw)); im.load()
        im = im.convert("RGB")
        if max(im.size) > 1600:
            im.thumbnail((1600, 1600), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, format="JPEG", quality=85, optimize=True)
        raw = out.getvalue()
    except Exception:
        await message.answer("⚠️ Не удалось обработать картинку. Пришли другую.")
        return
    b64 = base64.b64encode(raw).decode()

    data = await state.get_data()
    cfg = data["cfg"]
    cfg["bg_image"] = b64
    await state.update_data(cfg=cfg)
    await state.set_state(ConstructorSG.building)
    # Убираем загруженную картинку и сообщение-приглашение из чата
    try:
        await message.delete()
    except Exception:
        pass
    data2 = await state.get_data()
    prompt_id = data2.get("upload_prompt_id")
    if prompt_id:
        try:
            await message.bot.delete_message(message.chat.id, prompt_id)
        except Exception:
            pass
        await state.update_data(upload_prompt_id=None)
    await _send_or_update_preview(message, state, db)


@router.message(ConstructorSG.enter_bg_image, F.text == "/skip")
async def cb_bg_skip(message: Message, state: FSMContext, db: Database):
    await state.set_state(ConstructorSG.building)
    data = await state.get_data()
    prompt_id = data.get("upload_prompt_id")
    try:
        await message.delete()
    except Exception:
        pass
    if prompt_id:
        try:
            await message.bot.delete_message(message.chat.id, prompt_id)
        except Exception:
            pass
        await state.update_data(upload_prompt_id=None)
    await _send_or_update_preview(message, state, db)


async def _process_logo(message: Message, state: FSMContext, db: Database, raw: bytes):
    """Общая обработка логотипа: сжатие (с сохранением прозрачности) и сохранение."""
    import base64, io
    try:
        from PIL import Image
        Image.MAX_IMAGE_PIXELS = 40_000_000
        im = Image.open(io.BytesIO(raw)); im.load()
        im = im.convert("RGBA")  # RGBA сохраняет альфа-канал
        im.thumbnail((240, 240), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, format="PNG", optimize=True)  # PNG сохраняет прозрачность
        raw = out.getvalue()
    except Exception:
        await message.answer("❌ Не удалось обработать картинку. Пришли PNG или JPG.")
        return

    b64 = base64.b64encode(raw).decode()
    if len(b64) > 200_000:
        await message.answer("❌ Логотип слишком большой. Пришли картинку поменьше.")
        return

    data = await state.get_data()
    cfg = data["cfg"]
    ex = cfg.setdefault("extra_cfg", {})
    ex["logo_b64"] = b64
    await state.update_data(cfg=cfg)
    await state.set_state(ConstructorSG.building)
    # Убираем загруженную картинку/файл и сообщение-приглашение из чата
    try:
        await message.delete()
    except Exception:
        pass
    data2 = await state.get_data()
    prompt_id = data2.get("upload_prompt_id")
    if prompt_id:
        try:
            await message.bot.delete_message(message.chat.id, prompt_id)
        except Exception:
            pass
        await state.update_data(upload_prompt_id=None)
    await _send_or_update_preview(message, state, db)


@router.message(ConstructorSG.enter_logo, F.photo)
async def cb_logo_photo(message: Message, state: FSMContext, db: Database, bot):
    # Фото — Telegram уже убрал прозрачность, но логотип всё равно встроится
    photo = message.photo[-1]
    file = await bot.get_file(photo.file_id)
    buf = await bot.download_file(file.file_path)
    await _process_logo(message, state, db, buf.read())


@router.message(ConstructorSG.enter_logo, F.document)
async def cb_logo_document(message: Message, state: FSMContext, db: Database, bot):
    logger.info(f"[LOGO] Документ получен в состоянии enter_logo от {message.from_user.id}")
    # Документ сохраняет прозрачность PNG
    doc = message.document
    mime = (doc.mime_type or "").lower()
    name = (doc.file_name or "").lower()
    logger.info(f"[LOGO] mime={mime}, name={name}, size={doc.file_size}")
    is_image = mime.startswith("image/") or name.endswith((".png", ".jpg", ".jpeg", ".webp"))
    if not is_image:
        await message.answer("❌ Это не картинка. Пришли логотип в формате PNG, JPG или WEBP.")
        return
    # Защита: не качаем гигантские файлы
    if doc.file_size and doc.file_size > 5 * 1024 * 1024:
        await message.answer("❌ Файл слишком большой (макс. 5 МБ). Пришли логотип поменьше.")
        return
    file = await bot.get_file(doc.file_id)
    buf = await bot.download_file(file.file_path)
    await _process_logo(message, state, db, buf.read())


@router.message(ConstructorSG.enter_logo, F.text == "/skip")
async def cb_logo_skip(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    cfg = data["cfg"]
    ex = cfg.setdefault("extra_cfg", {})
    ex.pop("logo_b64", None)  # /skip убирает логотип
    await state.update_data(cfg=cfg)
    await state.set_state(ConstructorSG.building)
    prompt_id = data.get("upload_prompt_id")
    try:
        await message.delete()
    except Exception:
        pass
    if prompt_id:
        try:
            await message.bot.delete_message(message.chat.id, prompt_id)
        except Exception:
            pass
        await state.update_data(upload_prompt_id=None)
    await _send_or_update_preview(message, state, db)


@router.message(ConstructorSG.enter_logo, F.sticker)
async def cb_logo_sticker(message: Message, state: FSMContext, db: Database, bot):
    # Telegram превращает .webp в стикер! Скачиваем и обрабатываем как логотип.
    logger.info(f"[LOGO] Стикер в enter_logo, animated={message.sticker.is_animated}, video={message.sticker.is_video}")
    st = message.sticker
    if st.is_animated or st.is_video:
        await message.answer("❌ Анимированный стикер не подойдёт. Пришли статичную картинку (PNG-файл).")
        return
    file = await bot.get_file(st.file_id)
    buf = await bot.download_file(file.file_path)
    await _process_logo(message, state, db, buf.read())


@router.message(ConstructorSG.enter_logo)
async def cb_logo_fallback(message: Message, state: FSMContext, db: Database, bot):
    # Ловим ВСЁ остальное в состоянии логотипа — покажем что именно пришло
    ct = message.content_type
    logger.info(f"[LOGO] Fallback: content_type={ct}")
    await message.answer(
        f"⚠️ Я ожидаю картинку, а получил: <b>{ct}</b>.\n\n"
        "Пришли логотип как обычную картинку или PNG-файл. Или /skip чтобы убрать логотип."
    )


# ── Сохранение ─────────────────────────────────────────────────────────────

@router.callback_query(ConstructorSG.building, F.data == "con:save")
async def cb_save(call: CallbackQuery, state: FSMContext, db: Database):
    await call.answer()
    data = await state.get_data()

    # Режим редактирования существующего шаблона
    if data.get("edit_template_id"):
        cfg = data["cfg"]
        tpl_id = data["edit_template_id"]
        is_received = data.get("is_received", False)

        update_fields = {
            "layout": cfg["layout"],
            "font": cfg["font"],
            "title_font": cfg.get("title_font", "caveat"),
            "text_color": cfg["text_color"],
            "accent_color": cfg["accent_color"],
            "bg_color": cfg["bg_color"],
            "bg_image": cfg.get("bg_image"),
            "extra_cfg": cfg.get("extra_cfg", {}),
            "anon_nickname": cfg.get("anon_nickname"),
            "anon_avatar": cfg.get("anon_avatar"),
        }
        # Если редактируем полученный чужой шаблон — становимся владельцем
        if is_received:
            update_fields["is_edited"] = True

        await db.update_custom_template(tpl_id, **update_fields)
        await state.clear()

        note = ""
        if is_received:
            note = "\n\n👑 Ты отредактировал полученный шаблон — теперь ты его владелец, " \
                   "водяной знак создателя убран, можешь делиться им дальше."
        await call.message.answer(
            f"✅ Шаблон <b>«{data.get('edit_template_name', '')}»</b> обновлён!{note}"
        )
        return

    # Режим создания нового — спрашиваем название
    await state.set_state(ConstructorSG.enter_name)
    await call.message.answer("💾 Придумай название для шаблона:\n<i>Например: Мой золотой, Тёмная тема</i>")


@router.message(ConstructorSG.enter_name)
async def cb_save_name(message: Message, state: FSMContext, db: Database):
    name = message.text.strip()[:64]
    data = await state.get_data()
    cfg = data["cfg"]

    tpl = await db.create_custom_template(
        owner_id=message.from_user.id,
        creator_id=message.from_user.id,
        creator_username=message.from_user.username,
        name=name,
        layout=cfg["layout"],
        font=cfg["font"],
        title_font=cfg.get("title_font", "caveat"),
        text_color=cfg["text_color"],
        accent_color=cfg["accent_color"],
        bg_color=cfg["bg_color"],
        bg_image=cfg.get("bg_image"),
        extra_cfg=cfg.get("extra_cfg", {}),
        is_edited=False,
    )
    # Анон-профиль карточки (если задан в конструкторе)
    if cfg.get("anon_nickname") or cfg.get("anon_avatar"):
        await db.update_custom_template(
            tpl["id"],
            anon_nickname=cfg.get("anon_nickname"),
            anon_avatar=cfg.get("anon_avatar"),
        )
    await state.clear()
    await message.answer(
        f"✅ Шаблон <b>«{name}»</b> сохранён!\n\n"
        f"Найдёшь его в меню «🎨 Мои шаблоны». Оттуда можно использовать, "
        f"поделиться или удалить."
    )


@router.callback_query(F.data == "con:cancel")
async def cb_cancel(call: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    await call.answer("Закрыто")
    try:
        await call.message.delete()
    except Exception:
        pass
    # Возвращаем в меню «Твои шаблоны», чтобы был понятный путь дальше
    from handlers.my_templates import show_templates_list
    try:
        await show_templates_list(call.message, db, call.from_user.id)
    except Exception:
        await call.message.answer("❌ Конструктор закрыт. Открой меню командой /menu.")


@router.message(ConstructorSG.enter_key)
async def cb_enter_key(message: Message, state: FSMContext, db: Database, bot):
    key = message.text.strip()
    if not key.startswith("!"):
        key = "!" + key
    await state.clear()
    from handlers.my_templates import claim_template
    ok, msg = await claim_template(message.from_user.id, message.from_user.username, key, db, bot)
    await message.answer(msg)


# ВРЕМЕННАЯ ДИАГНОСТИКА: ловим документ в любом состоянии конструктора
@router.message(F.document)
async def _diag_any_document(message: Message, state: FSMContext):
    cur = await state.get_state()
    logger.info(f"[DIAG] Документ пришёл, текущее состояние FSM = {cur}, "
                f"mime={message.document.mime_type}, name={message.document.file_name}")
    if cur is None:
        await message.answer(
            "📎 Я получил файл, но сейчас не жду логотип. "
            "Открой конструктор → «🖼 Логотип магазина» и пришли файл там."
        )
